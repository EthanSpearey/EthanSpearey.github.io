//CS30 - Final Programming Challenge
//2025-01-24
//Ethan Spearey

//Variable Declarations - Included for convenience, but you don't have to use these.
//                        Feel free to handle this in a different way if you prefer.

let staticImages = [];  //Array to hold 1 image for each direction -> should use this to start  
let animationImagesLeft = [];  //Array to hold all 8 images in left direction
let animationImagesRight = [];  //Array to hold all 8 images in right direction
let animationImagesUp = [];  //Array to hold all 8 images in up direction
let animationImagesDown = [];  //Array to hold all 8 images in down direction
let foxWidth = 200;  //Starting X Position
let foxHeight = 200;  //Starting Y Position
let foxDirection = 0;  // 0 = Left | 1 = Right | 2 = Up | 3 = Down
let foxSize = 100;  //Starting Size of Fox

function preload()
{
  loadStatic();     //Defined at bottom
  loadAnimation();  //Also defined at bottom
}

function setup()
{
  createCanvas(windowWidth, windowHeight);
  imageMode(CENTER);
}

function draw()
{
  background(220);
  image(staticImages[foxDirection], foxWidth, foxHeight, foxSize, foxSize);
  if(keyIsDown(65) === true)  //Left
  {
    if(foxWidth > 0)  //Left Boundary
    {
      foxWidth--
    }
    foxDirection = 0
  }
  if(keyIsDown(68) === true)  //Right
  {
    if(foxWidth < windowWidth)  //Right Boundary
    {
      foxWidth++
    }
    foxDirection = 1
  }
  if(keyIsDown(87) === true)  //Up
  {
    if(foxHeight > 0)  //Up Boundary
    {
      foxHeight--
    }
    foxDirection = 2
  }
  if(keyIsDown(83) === true)  //Down
  {
    if(foxHeight < windowHeight)  //Down Boundary
    {
      foxHeight++
    }
    foxDirection = 3
  }
  if(keyIsDown(80) === true)  //Pepsi Mode Activated
  {
    foxSize = random([450], [25])
    tint(random(255), random(255), random(255));
  }
  else if(keyIsDown(80) === false)  //Pepsi Mode Deactivated (Reset to Normal Conditions)
  {
    foxSize = 100;
    noTint();
  }
}

function mouseClicked()
{
  if(mouseY < windowHeight/2)
  {
    if(foxSize < 450)
    {
      foxSize = foxSize + 25;
    }
  }
  if(mouseY > windowHeight/2)
  {
    if(foxSize > 50)
    {
      foxSize = foxSize - 25;
    }
  }
}

function loadStatic()
{
  staticImages.push(loadImage("assets/left1.png"));  //0 - Left
  staticImages.push(loadImage("assets/right1.png"));  //1 - Right
  staticImages.push(loadImage("assets/up1.png"));  //2 - Up
  staticImages.push(loadImage("assets/down1.png"));  //3 - Down
}

function loadAnimation()
{
  for(let i = 1; i <= 8; i++){
    animationImagesLeft.push(loadImage("assets/left" + i + ".png"));  //Left
    animationImagesRight.push(loadImage("assets/right" + i + ".png"));  //Right
    animationImagesUp.push(loadImage("assets/up" + i + ".png"));  //Up
    animationImagesDown.push(loadImage("assets/down" + i + ".png"));  //Down
  }
}